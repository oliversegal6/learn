package xyz.RPNCalculator;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Stack;

public class RPNcalculator {

	static HashMap<String, Integer> ops = new HashMap<>();

	public static void main(String[] args) {

		initOperators();

		Scanner inputStream = new Scanner(System.in);

		Stack<String> tks = new Stack<String>();
		Stack<Stack<String>> undoStks = new Stack<Stack<String>>();
		
		while (inputStream.hasNextLine()) {
			String equation = inputStream.nextLine();
			String[] inputs = equation.trim().split("[ \t]+");
			
			if(inputs.length == 0) break;
			
			evaluaterpn(inputs, tks, undoStks); 
				
			printResult(tks);
		}
		
	}

	private static void printResult(Stack<String> tks) {
		System.out.print("Stack: ");
		for (String tk : tks) {
			System.out.print(tk + " ");
		}
		System.out.println("\n");
	}

	private static void initOperators() {
		ops.put("undo", 0);
		ops.put("clear", 0);
		ops.put("sqrt", 1);
		ops.put("%", 2);
		ops.put("*", 2);
		ops.put("/", 2);
		ops.put("+", 2);
		ops.put("-", 2);
	}

	private static void evaluaterpn(String[] inputs, Stack<String> stks, Stack<Stack<String>> undoStks) {
		
		Double headNumber = 0.0;
		Double nextNumber = 0.0;
		Double result = 0.0;
		Boolean insucientParam = false;
		
		for (int i = 0; i < inputs.length; i++) {
			String input = inputs[i];
			
			if("".equals(input)) continue;
			
			try {
				Double.parseDouble(input);
				stks.push(input);
				undoStks.push((Stack<String>)stks.clone());
			} catch (NumberFormatException nfe) {
				
				Integer type = ops.get(input) == null ? 0 : ops.get(input);

				if (type == 1) {
					if(stks.size() < 1){
						insucientParam = true;
					} else {
						undoStks.push(stks);
						headNumber = Double.parseDouble(stks.pop());
					}
				} else if (type == 2) {
					if(stks.size() < 2){
						insucientParam = true;
					} else {
						undoStks.push(stks);
						headNumber = Double.parseDouble(stks.pop());
						nextNumber = Double.parseDouble(stks.pop());
					}
				}
				
				if(insucientParam){
					System.out.println("operator " + input + " (position: " + i + " ): insucient parameters");
					break;
				}
				
				calculate(stks, undoStks, headNumber, nextNumber, result, input);
				
			}
		}
	}

	private static void calculate(Stack<String> tks, Stack<Stack<String>> undoStks, Double headNumber,
			Double nextNumber, Double result, String input) {
		switch (input) {
		case "+":
			result = nextNumber + headNumber;
			break;
		case "-":
			result = nextNumber - headNumber;
			break;
		case "*":
			result = nextNumber * headNumber;
			break;
		case "/":
			if (headNumber == 0) {
				System.out.println("\nERROR: Cannot Divide by zero!\n");
			} else {
				result = nextNumber / headNumber;
				break;
			}
		case "%":
			result = nextNumber % headNumber;
			break;
		case "sqrt":
			result = Math.sqrt(headNumber);
			break;
		case "clear":
			tks.clear();
			break;
		case "undo":
			undoStks.pop();
			tks.clear();
			tks.addAll((Stack<String>)undoStks.peek().clone());
			break;

		}
		
		if (result != 0.0) {
			tks.push(result.toString());
		}
	}
	
}